# ✈️ Block Flight Game

Welcome to Block Flight Game! This project features a custom graphics engine designed to scale from old office hardware all the way up to modern PCs.

## 📋 System Requirements

### 💻 Minimum Requirements (For Low / Normal / Ultra / Ultimate Modes)
* **Processor (CPU):** Any Intel, AMD, or ARM processor (Even older dual-core processors from 2006 like Intel Core 2 Duo).
* **Graphics (GPU):** No dedicated graphics card required! The custom-built 2D Canvas Raycaster calculates all 3D math on the CPU, making it work perfectly on vintage integrated graphics (like Intel GMA 3100).
* **Memory (RAM):** 2 GB RAM.
* **Storage:** Less than 5 MB of free space.

---

### 🚀 Recommended Requirements (For "Can it run Crysis" Mode)
* **Processor (CPU):** Intel Core i3 / AMD Ryzen 3 or newer (released after 2015).
* **Graphics (GPU):** A dedicated graphics card or modern integrated chip that supports **WebGL2** and **OpenGL 3.3+**. 
  * *Examples:* NVIDIA GeForce GT 710 / GTX 1050, AMD Radeon RX 550, or modern Intel HD/UHD Graphics.
* **Memory (RAM):** 4 GB or 8 GB RAM (required to process the larger 2048x2048 high-resolution textures smoothly).

---

## 🛠️ Engine Design Note
Lower graphics options bypass standard GPU limits entirely by running a pure mathematical **2D Canvas Raycaster** inside the browser. The "Crysis" option unlocks true hardware-accelerated **WebGL2** rendering.
